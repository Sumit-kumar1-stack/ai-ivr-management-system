import {
  Job,
  Worker,
} from "bullmq";

import {
  redisConnection,
} from "@/lib/redis";

import {
  COMMUNICATION_FALLBACK_JOB_NAME,
  COMMUNICATION_JOB_NAME,
  COMMUNICATION_QUEUE_NAME,
  type CommunicationCampaignJobData,
  type CommunicationFallbackJobData,
  type CommunicationJobData,
} from "@/services/communication/communication-campaign-queue.service";

import {
  runCommunicationCampaign,
} from "@/services/communication/communication-campaign-runner.service";

import {
  handleWhatsAppFailureFallback,
} from "@/services/communication/communication-fallback.service";

//--------------------------------------------------
// Worker State
//--------------------------------------------------

let worker:
  Worker<
    CommunicationJobData,
    unknown
  > |
  null =
    null;

//--------------------------------------------------
// Initialize
//--------------------------------------------------

export function initializeCommunicationCampaignWorker():
  Worker<
    CommunicationJobData,
    unknown
  > {
  if (
    worker
  ) {
    return worker;
  }

  worker =
    new Worker<
      CommunicationJobData,
      unknown
    >(
      COMMUNICATION_QUEUE_NAME,

      async (
        job:
          Job<
            CommunicationJobData,
            unknown
          >
      ) => {
        //------------------------------------------------
        // Communication Campaign
        //------------------------------------------------

        if (
          job.name ===
          COMMUNICATION_JOB_NAME
        ) {
          const data =
            job.data as
              CommunicationCampaignJobData;

          const campaignId =
            data
              .communicationCampaignId
              ?.trim();

          if (
            !campaignId
          ) {
            throw new Error(
              "Communication campaign job is missing communicationCampaignId"
            );
          }

          await job
            .updateProgress(
              0
            );

          const result =
            await runCommunicationCampaign(
              campaignId
            );

          await job
            .updateProgress(
              100
            );

          return result;
        }

        //------------------------------------------------
        // WhatsApp -> SMS Fallback
        //------------------------------------------------

        if (
          job.name ===
          COMMUNICATION_FALLBACK_JOB_NAME
        ) {
          const data =
            job.data as
              CommunicationFallbackJobData;

          const outboundMessageId =
            data
              .outboundMessageId
              ?.trim();

          if (
            !outboundMessageId
          ) {
            throw new Error(
              "Communication fallback job is missing outboundMessageId"
            );
          }

          const result =
            await handleWhatsAppFailureFallback(
              outboundMessageId
            );

          await job
            .updateProgress(
              100
            );

          return result;
        }

        //------------------------------------------------
        // Unsupported
        //------------------------------------------------

        throw new Error(
          `Unsupported communication job: ${job.name}`
        );
      },

      {
        connection:
          redisConnection,

        concurrency:
          getConcurrency(),
      }
    );

  //------------------------------------------------
  // Worker Failure
  //------------------------------------------------

  worker.on(
    "failed",
    (
      job,
      error
    ) => {
      console.error(
        "Communication worker job failed",
        {
          jobId:
            job?.id,

          jobName:
            job?.name,

          error:
            error.message,
        }
      );
    }
  );

  return worker;
}

//--------------------------------------------------
// Close
//--------------------------------------------------

export async function closeCommunicationCampaignWorker():
  Promise<void> {
  if (
    !worker
  ) {
    return;
  }

  const current =
    worker;

  worker =
    null;

  await current.close();
}

//--------------------------------------------------
// Concurrency
//--------------------------------------------------

function getConcurrency():
  number {
  const parsed =
    Number(
      process.env
        .COMMUNICATION_CAMPAIGN_CONCURRENCY ??
      2
    );

  if (
    !Number.isFinite(
      parsed
    )
  ) {
    return 2;
  }

  return Math.max(
    1,
    Math.min(
      10,
      Math.round(
        parsed
      )
    )
  );
}