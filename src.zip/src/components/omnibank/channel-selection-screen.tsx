"use client";

import {
  ArrowLeft,
  ArrowRight,
  AudioLines,
  Check,
  MessageSquare,
  PhoneCall,
  Smartphone,
  Sparkles,
  Zap,
} from "lucide-react";

import {
  useMemo,
  useState,
} from "react";

import { useRouter } from "next/navigation";

import type {
  CommunicationPlan,
} from "@/config/communication-plan";

//--------------------------------------------------
// Channel Types
//--------------------------------------------------

type ChannelId =
  | "sms"
  | "whatsapp"
  | "ai-voice"
  | "ivr";

//--------------------------------------------------
// Channel Config
//--------------------------------------------------

const channels = [
  {
    id:
      "sms",

    title:
      "SMS Broadcast",

    description:
      "Direct mobile messaging with 98% open rates. Best for urgent alerts.",

    icon:
      MessageSquare,
  },

  {
    id:
      "whatsapp",

    title:
      "WhatsApp Business",

    description:
      "Rich media messaging and interactive buttons. Ideal for engagement.",

    icon:
      Smartphone,
  },

  {
    id:
      "ai-voice",

    title:
      "AI Voice Assistant",

    description:
      "Automated human-like voice calls for personalized follow-ups.",

    icon:
      AudioLines,
  },

  {
    id:
      "ivr",

    title:
      "IVR Call",

    description:
      "Interactive voice response menus for large scale data collection.",

    icon:
      PhoneCall,
  },
] satisfies Array<{
  id:
    ChannelId;

  title:
    string;

  description:
    string;

  icon:
    typeof MessageSquare;
}>;

//--------------------------------------------------
// Props
//--------------------------------------------------

interface ChannelSelectionScreenProps {
  plan:
    CommunicationPlan;
}

//--------------------------------------------------
// Component
//--------------------------------------------------

export default function ChannelSelectionScreen({
  plan,
}: ChannelSelectionScreenProps) {
  const [
    selectedChannels,
    setSelectedChannels,
  ] =
useState<
  ChannelId[]
>([
  "sms",
  "whatsapp",
]);

const router =
  useRouter();

const [
  saving,
  setSaving,
] =
  useState(
    false
  );

const [
  saveError,
  setSaveError,
] =
  useState<
    string | null
  >(
    null
  );

  //--------------------------------------------------
  // Toggle
  //--------------------------------------------------

  function toggleChannel(
    channelId:
      ChannelId
  ) {
    setSelectedChannels(
      current =>
        current.includes(
          channelId
        )
          ? current.filter(
              item =>
                item !==
                channelId
            )
          : [
              ...current,
              channelId,
            ]
    );
  }

  //--------------------------------------------------
  // Visual-only Estimator For Current UI Phase
  //--------------------------------------------------

  const estimate =
    useMemo(
      () => {
        const count =
          selectedChannels
            .length;

        const platformFee =
          count *
          60;

        const messaging =
          count *
          222.75;

        return {
          count,

          platformFee,

          messaging,

          total:
            platformFee +
            messaging,
        };
      },
      [
        selectedChannels,
      ]
    );

    //--------------------------------------------------
// Continue To Summary
//--------------------------------------------------

async function continueToSummary():
  Promise<void> {
  if (
    selectedChannels
      .length ===
    0 ||
    saving
  ) {
    return;
  }

  setSaving(
    true
  );

  setSaveError(
    null
  );

  try {
    //------------------------------------------------
    // UI Channel → API Channel
    //------------------------------------------------

    const apiChannels =
      selectedChannels.map(
        channel => {
          switch (
            channel
          ) {
            case "sms":
              return "SMS";

            case "whatsapp":
              return "WHATSAPP";

            case "ai-voice":
              return "AI_VOICE";

            case "ivr":
              return "IVR";
          }
        }
      );

    //------------------------------------------------
    // Standalone demo audience.
    //
    // Team-owned CSV integration will later replace
    // only these audience fields.
    //------------------------------------------------

    const response =
      await fetch(
        "/api/communication/campaigns",
        {
          method:
            "POST",

          headers: {
            "Content-Type":
              "application/json",
          },

          body:
            JSON.stringify({
              name:
                "Q4 High-Yield Outreach",

              audienceSourceId:
                "demo-q4-high-net-worth",

              audienceSourceName:
                "Q4_High_Net_Worth_Individuals.csv",

              recipientCount:
                42850,

              channels:
                apiChannels,
            }),
        }
      );

    const payload =
      await response
        .json();

    if (
      !response.ok ||
      !payload
        ?.success ||
      !payload
        ?.data
        ?.id
    ) {
      throw new Error(
        payload
          ?.message ??
        "Campaign draft could not be saved"
      );
    }

    //------------------------------------------------
    // Summary
    //------------------------------------------------

    router.push(
      `/communication/campaigns/new/summary?campaign=${encodeURIComponent(
        payload.data.id
      )}`
    );
  } catch (
    error
  ) {
    setSaveError(
      error instanceof
        Error
        ? error.message
        : "Campaign draft could not be saved"
    );
  } finally {
    setSaving(
      false
    );
  }
}

  //--------------------------------------------------
  // Render
  //--------------------------------------------------

  return (
    <div className="min-h-screen">

      {/* =========================================
          HEADER
      ========================================= */}

      <header
        className="
          border-b
          border-[#c1c6d5]/45
          bg-[#f9f9ff]/95
          px-6
          py-5
          backdrop-blur-xl
          md:px-10
          xl:px-[82px]
        "
      >
        <div
          className="
            mx-auto
            flex
            max-w-[1040px]
            flex-col
            gap-6
            xl:flex-row
            xl:items-center
            xl:justify-between
          "
        >
          <div>
            <h2
              className="
                text-[30px]
                font-semibold
                leading-none
                tracking-[-0.035em]
                text-black
              "
            >
              Launch New Campaign
            </h2>

            <p
              className="
                mt-1
                text-[12px]
                text-[#86868b]
              "
            >
              Step 2 of 3 • Selection Stage
            </p>
          </div>

          {/* Steps */}

          <div
            className="
              flex
              items-center
              gap-3
              text-[12px]
              font-semibold
            "
          >
            <div className="flex items-center gap-2">
              <div
                className="
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  rounded-full
                  bg-[#0066cc]
                  text-white
                "
              >
                <Check
                  size={17}
                />
              </div>

              <span className="hidden sm:inline">
                Data Source
              </span>
            </div>

            <div
              className="
                h-[2px]
                w-8
                bg-[#c1c6d5]
              "
            />

            <div className="flex items-center gap-2">
              <div
                className="
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  rounded-full
                  bg-[#004e9f]
                  font-bold
                  text-white
                  ring-4
                  ring-[#d7e3ff]
                "
              >
                2
              </div>

              <span>
                Channels
              </span>
            </div>

            <div
              className="
                h-[2px]
                w-8
                bg-[#c1c6d5]
              "
            />

            <div
              className="
                flex
                items-center
                gap-2
                opacity-35
              "
            >
              <div
                className="
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  rounded-full
                  border
                  border-[#c1c6d5]
                  bg-[#f2f3fc]
                "
              >
                3
              </div>

              <span className="hidden sm:inline">
                Summary
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* =========================================
          CONTENT
      ========================================= */}

      <div
        className="
          mx-auto
          max-w-[1040px]
          px-6
          pb-36
          pt-12
          md:px-10
          xl:px-0
        "
      >
        {/* Title */}

        <section>
          <h1
            className="
              text-[31px]
              font-semibold
              tracking-[-0.035em]
              text-black
            "
          >
            Select Outreach Channels
          </h1>

          <p
            className="
              mt-2
              max-w-[680px]
              text-[16px]
              leading-6
              text-[#414753]
            "
          >
            Choose the communication platforms for this
            campaign. You can select multiple channels to
            increase engagement across your customer base.
          </p>
        </section>

        {/* =========================================
            CHANNEL CARDS
        ========================================= */}

        <section
          className="
            mt-12
            grid
            grid-cols-1
            gap-6
            sm:grid-cols-2
            xl:grid-cols-4
          "
        >
          {channels.map(
            channel => {
              const Icon =
                channel.icon;

              const active =
                selectedChannels
                  .includes(
                    channel.id
                  );

              return (
                <button
                  key={
                    channel.id
                  }
                  type="button"
                  onClick={
                    () =>
                      toggleChannel(
                        channel.id
                      )
                  }
                  className={[
                    "relative min-h-[282px] rounded-[13px] border bg-white p-6 text-left",
                    "transition-all duration-200",
                    "hover:-translate-y-[2px] hover:shadow-[0_18px_40px_rgba(0,0,0,0.05)]",
                    active
                      ? "border-2 border-[#0066cc]"
                      : "border-[#c1c6d5]",
                  ].join(
                    " "
                  )}
                >
                  {/* Selection */}

                  <span
                    className={[
                      "absolute right-5 top-5 flex h-5 w-5 items-center justify-center rounded-full",
                      active
                        ? "bg-[#0066cc] text-white"
                        : "border-2 border-[#c1c6d5] bg-white",
                    ].join(
                      " "
                    )}
                  >
                    {active && (
                      <Check
                        size={13}
                        strokeWidth={
                          3
                        }
                      />
                    )}
                  </span>

                  {/* Icon */}

                  <div
                    className="
                      flex
                      h-[50px]
                      w-[50px]
                      items-center
                      justify-center
                      rounded-[9px]
                      bg-[#f0f1fa]
                      text-[#005cba]
                    "
                  >
                    <Icon
                      size={27}
                      strokeWidth={
                        2
                      }
                    />
                  </div>

                  <h3
                    className="
                      mt-7
                      text-[21px]
                      font-bold
                      leading-7
                      tracking-[-0.025em]
                      text-black
                    "
                  >
                    {channel.title}
                  </h3>

                  <p
                    className="
                      mt-2
                      text-[14px]
                      leading-[23px]
                      text-[#414753]
                    "
                  >
                    {
                      channel.description
                    }
                  </p>
                </button>
              );
            }
          )}
        </section>

        {/* =========================================
            OPTIMIZATION + BUDGET
        ========================================= */}

        <section
          className="
            mt-[82px]
            grid
            grid-cols-1
            gap-10
            xl:grid-cols-[1fr_263px]
          "
        >
          {/* Smart Channeling */}

          <div
            className="
              min-h-[360px]
              rounded-[25px]
              border
              border-[#d9dce8]
              bg-[#f2f3fc]
              p-8
              md:p-12
            "
          >
            <div
              className="
                grid
                h-full
                gap-8
                md:grid-cols-[200px_1fr]
                md:items-center
              "
            >
              {/* Illustration */}

              <div
                className="
                  flex
                  aspect-square
                  items-center
                  justify-center
                  rounded-[18px]
                  bg-gradient-to-br
                  from-[#d7e3ff]
                  via-white
                  to-[#aac7ff]
                  shadow-[0_18px_35px_rgba(0,0,0,0.08)]
                "
              >
                <div
                  className="
                    flex
                    h-24
                    w-24
                    items-center
                    justify-center
                    rounded-[25px]
                    border
                    border-white/80
                    bg-white/65
                    text-[#0066cc]
                    shadow-lg
                    backdrop-blur-xl
                  "
                >
                  <Smartphone
                    size={51}
                    strokeWidth={
                      1.6
                    }
                  />
                </div>
              </div>

              <div>
                <div
                  className="
                    inline-flex
                    items-center
                    gap-1
                    rounded-full
                    bg-[#0066cc]
                    px-3
                    py-1
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.06em]
                    text-white
                  "
                >
                  {plan.features
                    .smartChanneling ? (
                    <>
                      <Zap
                        size={12}
                        fill="currentColor"
                      />

                      Smart Channeling
                    </>
                  ) : (
                    <>
                      <Sparkles
                        size={12}
                      />

                      Premium Optimization
                    </>
                  )}
                </div>

                <h3
                  className="
                    mt-4
                    text-[30px]
                    font-bold
                    leading-[34px]
                    tracking-[-0.03em]
                    text-[#004e9f]
                  "
                >
                  Channel
                  <br />
                  Optimization
                </h3>

                <p
                  className="
                    mt-3
                    max-w-[420px]
                    text-[14px]
                    leading-[21px]
                    text-[#414753]
                  "
                >
                  {plan.features
                    .smartChanneling
                    ? "OmniBank AI will automatically route messages to the most cost-effective channel based on recipient behavior history."
                    : "Standard campaigns use the channels you select. Automatic cross-channel optimization becomes available with Premium."}
                </p>

                <div
                  className="
                    mt-7
                    flex
                    items-center
                    gap-7
                  "
                >
                  <div>
                    <p
                      className="
                        text-[11px]
                        font-bold
                        text-[#5f5e60]
                      "
                    >
                      EST. REACH
                    </p>

                    <p
                      className="
                        text-[19px]
                        font-bold
                        text-black
                      "
                    >
                      124,500+
                    </p>
                  </div>

                  <div
                    className="
                      h-10
                      w-px
                      bg-[#c1c6d5]
                    "
                  />

                  <div>
                    <p
                      className="
                        text-[11px]
                        font-bold
                        text-[#5f5e60]
                      "
                    >
                      EST. CONV.
                    </p>

                    <p
                      className="
                        text-[19px]
                        font-bold
                        text-black
                      "
                    >
                      14.2%
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Budget */}

          <div
            className="
              flex
              min-h-[360px]
              flex-col
              justify-between
              rounded-[25px]
              bg-[#0b70d1]
              p-9
              text-white
            "
          >
            <div>
              <h3
                className="
                  text-[20px]
                  font-bold
                "
              >
                Budget Estimator
              </h3>

              <div
                className="
                  mt-8
                  space-y-4
                  text-[14px]
                "
              >
                <div
                  className="
                    flex
                    items-center
                    justify-between
                    gap-5
                  "
                >
                  <span>
                    Selected Channels
                  </span>

                  <strong>
                    {String(
                      estimate.count
                    ).padStart(
                      2,
                      "0"
                    )}
                  </strong>
                </div>

                <div
                  className="
                    flex
                    items-center
                    justify-between
                  "
                >
                  <span>
                    Platform Fee
                  </span>

                  <strong>
                    $
                    {
                      estimate.platformFee
                        .toFixed(
                          2
                        )
                    }
                  </strong>
                </div>

                <div
                  className="
                    flex
                    items-center
                    justify-between
                  "
                >
                  <span>
                    Est. Messaging
                  </span>

                  <strong>
                    $
                    {
                      estimate.messaging
                        .toFixed(
                          2
                        )
                    }
                  </strong>
                </div>
              </div>
            </div>

            <div
              className="
                border-t
                border-white/20
                pt-7
              "
            >
              <div
                className="
                  flex
                  items-end
                  justify-between
                  gap-4
                "
              >
                <span
                  className="
                    text-[11px]
                    font-semibold
                    uppercase
                    tracking-wide
                    text-white/70
                  "
                >
                  Daily
                  <br />
                  Max
                </span>

                <strong
                  className="
                    text-[27px]
                    tracking-[-0.03em]
                  "
                >
                  $
                  {
                    estimate.total
                      .toFixed(
                        2
                      )
                  }
                </strong>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* =========================================
          FOOTER ACTIONS
      ========================================= */}

      <footer
        className="
          fixed
          bottom-0
          left-0
          right-0
          z-30
          border-t
          border-[#c1c6d5]/40
          bg-[#f9f9ff]/95
          px-6
          py-5
          backdrop-blur-xl
          lg:left-[262px]
        "
      >
        <div
          className="
            mx-auto
            flex
            max-w-[1040px]
            items-center
            justify-between
          "
        >
          <button
            type="button"
            className="
              flex
              items-center
              gap-2
              rounded-full
              px-4
              py-3
              text-[14px]
              font-bold
              text-black
              transition
              hover:bg-[#e6e8f1]
            "
          >
            <ArrowLeft
              size={18}
            />

            Back
          </button>

          <div
            className="
              flex
              items-center
              gap-5
            "
          >
            <button
              type="button"
              className="
                hidden
                rounded-full
                px-5
                py-3
                text-[14px]
                font-bold
                text-[#004e9f]
                hover:bg-[#d7e3ff]
                sm:block
              "
            >
              Save as Draft
            </button>

            <button
              type="button"
              disabled={
                selectedChannels
                  .length ===
                0
              }
              className="
                flex
                min-w-[200px]
                items-center
                justify-center
                gap-3
                rounded-full
                bg-[#0056ad]
                px-7
                py-3
                text-[14px]
                font-bold
                text-white
                shadow-sm
                transition
                hover:bg-[#004e9f]
                disabled:cursor-not-allowed
                disabled:opacity-40
              "
            >
              Continue

              <ArrowRight
                size={19}
              />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}