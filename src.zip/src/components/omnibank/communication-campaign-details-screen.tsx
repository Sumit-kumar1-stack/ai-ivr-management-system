"use client";

import {
  Activity,
  ArrowLeft,
  Bot,
  CheckCircle2,
  Loader2,
  MessageSquare,
  PhoneCall,
  RefreshCw,
  Smartphone,
  TrendingUp,
  UserCheck,
  Users,
  XCircle,
} from "lucide-react";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useRouter,
} from "next/navigation";

import type {
  CommunicationCampaignDetailsDTO,
  CommunicationChannelRuntimeStatus,
  CommunicationInsightStatus,
} from "@/types/communication-campaign-details";

//--------------------------------------------------
// API
//--------------------------------------------------

interface DetailsApiResponse {
  success:
    boolean;

  data?:
    CommunicationCampaignDetailsDTO;

  message?:
    string;
}

//--------------------------------------------------
// Props
//--------------------------------------------------

interface CommunicationCampaignDetailsScreenProps {
  campaignId:
    string;
}

//--------------------------------------------------
// Screen
//--------------------------------------------------

export default function CommunicationCampaignDetailsScreen({
  campaignId,
}: CommunicationCampaignDetailsScreenProps) {
  const router =
    useRouter();

  const [
    details,
    setDetails,
  ] =
    useState<
      CommunicationCampaignDetailsDTO |
      null
    >(
      null
    );

  const [
    page,
    setPage,
  ] =
    useState(
      1
    );

  const [
    loading,
    setLoading,
  ] =
    useState(
      true
    );

  const [
    refreshing,
    setRefreshing,
  ] =
    useState(
      false
    );

  const [
    error,
    setError,
  ] =
    useState<
      string |
      null
    >(
      null
    );

  //--------------------------------------------------
  // Load
  //--------------------------------------------------

  const load =
    useCallback(
      async (
        targetPage:
          number,

        background =
          false
      ): Promise<void> => {
        if (
          background
        ) {
          setRefreshing(
            true
          );
        } else {
          setLoading(
            true
          );
        }

        try {
          const response =
            await fetch(
              `/api/communication/campaigns/${encodeURIComponent(
                campaignId
              )}/details?page=${targetPage}&pageSize=25`,
              {
                cache:
                  "no-store",
              }
            );

          const payload =
            await response
              .json() as
              DetailsApiResponse;

          if (
            !response.ok ||
            !payload.success ||
            !payload.data
          ) {
            throw new Error(
              payload.message ??
              "Campaign details could not be loaded"
            );
          }

          setDetails(
            payload.data
          );

          setPage(
            payload
              .data
              .pagination
              .page
          );

          setError(
            null
          );
        } catch (
          loadError
        ) {
          setError(
            loadError instanceof
              Error
              ? loadError.message
              : "Campaign details could not be loaded"
          );
        } finally {
          setLoading(
            false
          );

          setRefreshing(
            false
          );
        }
      },
      [
        campaignId,
      ]
    );

  //--------------------------------------------------
  // Initial + Page
  //--------------------------------------------------

useEffect(
  () => {
    const timer =
      window.setTimeout(
        () => {
          void load(
            page
          );
        },
        0
      );

    return () => {
      window.clearTimeout(
        timer
      );
    };
  },
  [
    load,
    page,
  ]
);

  //--------------------------------------------------
  // Lightweight Live Refresh
  //--------------------------------------------------

  useEffect(
    () => {
      const timer =
        window.setInterval(
          () => {
            void load(
              page,
              true
            );
          },
          15_000
        );

      return () => {
        window.clearInterval(
          timer
        );
      };
    },
    [
      load,
      page,
    ]
  );

  //--------------------------------------------------
  // Formatters
  //--------------------------------------------------

  const numberFormatter =
    useMemo(
      () =>
        new Intl.NumberFormat(
          "en-US"
        ),
      []
    );

  //--------------------------------------------------
  // Loading
  //--------------------------------------------------

  if (
    loading &&
    !details
  ) {
    return (
      <div
        className="
          flex
          min-h-[70vh]
          items-center
          justify-center
        "
      >
        <Loader2
          className="
            animate-spin
            text-[#0066cc]
          "
          size={36}
        />
      </div>
    );
  }

  //--------------------------------------------------
  // Fatal Error
  //--------------------------------------------------

  if (
    !details
  ) {
    return (
      <div
        className="
          mx-auto
          max-w-[1040px]
          px-6
          py-20
        "
      >
        <div
          className="
            rounded-2xl
            border
            border-red-200
            bg-red-50
            p-6
            text-red-700
          "
        >
          {error ??
            "Campaign details could not be loaded."}
        </div>
      </div>
    );
  }

  const {
    campaign,
    funnel,
    secondaryMetrics,
    channelMix,
    recipients,
    pagination,
  } =
    details;

  return (
    <div
      className="
        min-h-screen
        bg-[#f9f9ff]
        pb-16
      "
    >
      {/* =========================================
          HEADER
      ========================================= */}

      <header
        className="
          border-b
          border-[#c1c6d5]/45
          bg-[#f9f9ff]/95
          px-6
          py-6
          backdrop-blur-xl
          md:px-10
          xl:px-[82px]
        "
      >
        <div
          className="
            mx-auto
            flex
            max-w-[1180px]
            flex-col
            gap-5
            md:flex-row
            md:items-center
            md:justify-between
          "
        >
          <div>
            <button
              type="button"
              onClick={
                () =>
                  router.push(
                    "/communication/campaigns/new/channels"
                  )
              }
              className="
                mb-4
                inline-flex
                items-center
                gap-2
                text-[13px]
                font-semibold
                text-[#5f6368]
                transition
                hover:text-black
              "
            >
              <ArrowLeft
                size={16}
              />

              Campaigns
            </button>

            <div
              className="
                flex
                flex-wrap
                items-center
                gap-3
              "
            >
              <h1
                className="
                  text-[30px]
                  font-semibold
                  tracking-[-0.04em]
                  text-[#191c22]
                "
              >
                {campaign.name}
              </h1>

              <CampaignBadge
                status={
                  campaign.status
                }
              />
            </div>

            <p
              className="
                mt-2
                text-[13px]
                text-[#727784]
              "
            >
              {campaign.audienceSourceName}
              {" · "}
              {numberFormatter.format(
                campaign.recipientCount
              )}{" "}
              recipients
              {" · "}
              {campaign.tier}
            </p>
          </div>

          <button
            type="button"
            onClick={
              () =>
                void load(
                  page,
                  true
                )
            }
            disabled={
              refreshing
            }
            className="
              inline-flex
              h-11
              items-center
              justify-center
              gap-2
              rounded-full
              border
              border-[#c1c6d5]
              bg-white
              px-5
              text-[13px]
              font-bold
              text-[#191c22]
              transition
              hover:bg-[#f2f3fc]
              disabled:opacity-50
            "
          >
            <RefreshCw
              size={16}
              className={
                refreshing
                  ? "animate-spin"
                  : ""
              }
            />

            Refresh
          </button>
        </div>
      </header>

      <main
        className="
          mx-auto
          max-w-[1180px]
          px-6
          py-10
          md:px-10
          xl:px-0
        "
      >
        {/* =====================================
            ERROR BANNER
        ===================================== */}

        {error && (
          <div
            className="
              mb-6
              rounded-xl
              border
              border-red-200
              bg-red-50
              px-5
              py-4
              text-[13px]
              text-red-700
            "
          >
            {error}
          </div>
        )}

        {/* =====================================
            FUNNEL
        ===================================== */}

        <section>
          <div
            className="
              flex
              items-end
              justify-between
              gap-4
            "
          >
            <div>
              <p
                className="
                  text-[11px]
                  font-bold
                  uppercase
                  tracking-[0.14em]
                  text-[#727784]
                "
              >
                Live Performance
              </p>

              <h2
                className="
                  mt-2
                  text-[26px]
                  font-semibold
                  tracking-[-0.035em]
                  text-[#191c22]
                "
              >
                Campaign Funnel
              </h2>
            </div>

            <p
              className="
                hidden
                text-[12px]
                text-[#727784]
                md:block
              "
            >
              Auto-refreshes every 15 seconds
            </p>
          </div>

          <div
            className="
              mt-6
              grid
              gap-4
              sm:grid-cols-2
              xl:grid-cols-4
            "
          >
            <MetricCard
              label="Sent"
              value={
                numberFormatter.format(
                  funnel.sent
                )
              }
              icon={
                Activity
              }
            />

            <MetricCard
              label="Delivered"
              value={
                numberFormatter.format(
                  funnel.delivered
                )
              }
              icon={
                CheckCircle2
              }
            />

            <MetricCard
              label="Opened"
              value={
                numberFormatter.format(
                  funnel.opened
                )
              }
              icon={
                TrendingUp
              }
            />

            <MetricCard
              label="Converted"
              value={
                numberFormatter.format(
                  funnel.converted
                )
              }
              icon={
                UserCheck
              }
            />
          </div>
        </section>

        {/* =====================================
            SECONDARY METRICS
        ===================================== */}

        <section
          className="
            mt-5
            grid
            gap-4
            sm:grid-cols-2
            xl:grid-cols-4
          "
        >
          <SmallMetric
            label="Dropped"
            value={
              numberFormatter.format(
                secondaryMetrics.dropped
              )
            }
          />

          <SmallMetric
            label="Bounced"
            value={
              numberFormatter.format(
                secondaryMetrics.bounced
              )
            }
          />

          <SmallMetric
            label="Opted Out"
            value={
              numberFormatter.format(
                secondaryMetrics.unsubscribed
              )
            }
          />

          <SmallMetric
            label="Avg. Time to Open"
            value={
              secondaryMetrics
                .averageTimeToOpenMinutes ===
              null
                ? "—"
                : `${secondaryMetrics.averageTimeToOpenMinutes}m`
            }
          />
        </section>

        {/* =====================================
            CHANNEL MIX
        ===================================== */}

        <section
          className="
            mt-10
            rounded-[24px]
            border
            border-[#d9dce8]
            bg-white
            p-7
            md:p-9
          "
        >
          <div>
            <p
              className="
                text-[11px]
                font-bold
                uppercase
                tracking-[0.14em]
                text-[#727784]
              "
            >
              Channel Mix
            </p>

            <h2
              className="
                mt-2
                text-[24px]
                font-semibold
                tracking-[-0.03em]
                text-[#191c22]
              "
            >
              Delivery by Channel
            </h2>
          </div>

          <div
            className="
              mt-7
              grid
              gap-4
              md:grid-cols-2
            "
          >
            <ChannelCard
              title="SMS"
              subtitle={`${numberFormatter.format(
                channelMix.SMS.attempted
              )} attempts`}
              metric={`${channelMix.SMS.deliveryRate}% delivered`}
              icon={
                MessageSquare
              }
              enabled={
                campaign.channels.includes(
                  "SMS"
                )
              }
            />

            <ChannelCard
              title="WhatsApp"
              subtitle={`${numberFormatter.format(
                channelMix.WHATSAPP.attempted
              )} attempts · ${numberFormatter.format(
                channelMix.WHATSAPP.read
              )} read`}
              metric={`${channelMix.WHATSAPP.deliveryRate}% delivered`}
              icon={
                Smartphone
              }
              enabled={
                campaign.channels.includes(
                  "WHATSAPP"
                )
              }
            />

            <ChannelCard
              title="AI Voice"
              subtitle={`${numberFormatter.format(
                channelMix.AI_VOICE.attempted
              )} calls · ${formatDuration(
                channelMix
                  .AI_VOICE
                  .averageDurationSeconds
              )} avg`}
              metric={`${channelMix.AI_VOICE.answerRate}% answered`}
              icon={
                Bot
              }
              enabled={
                campaign.channels.includes(
                  "AI_VOICE"
                )
              }
            />

            <ChannelCard
              title="IVR"
              subtitle={`${numberFormatter.format(
                channelMix.IVR.attempted
              )} calls · ${formatDuration(
                channelMix
                  .IVR
                  .averageDurationSeconds
              )} avg`}
              metric={`${channelMix.IVR.answerRate}% answered`}
              icon={
                PhoneCall
              }
              enabled={
                campaign.channels.includes(
                  "IVR"
                )
              }
            />
          </div>
        </section>

        {/* =====================================
            RECIPIENT INSIGHTS
        ===================================== */}

        <section
          className="
            mt-10
            overflow-hidden
            rounded-[24px]
            border
            border-[#d9dce8]
            bg-white
          "
        >
          <div
            className="
              flex
              flex-col
              gap-3
              border-b
              border-[#e6e8f1]
              px-7
              py-6
              md:flex-row
              md:items-center
              md:justify-between
            "
          >
            <div>
              <p
                className="
                  text-[11px]
                  font-bold
                  uppercase
                  tracking-[0.14em]
                  text-[#727784]
                "
              >
                Recipient Insights
              </p>

              <h2
                              className="
                  mt-2
                  text-[24px]
                  font-semibold
                  tracking-[-0.03em]
                  text-[#191c22]
                "
              >
                Unified Channel Status
              </h2>
            </div>

            <div
              className="
                inline-flex
                items-center
                gap-2
                text-[12px]
                text-[#727784]
              "
            >
              <Users
                size={16}
              />

              {numberFormatter.format(
                pagination.total
              )}{" "}
              recipients
            </div>
          </div>

          <div
            className="
              overflow-x-auto
            "
          >
            <table
              className="
                min-w-[1080px]
                w-full
                border-collapse
                text-left
              "
            >
              <thead
                className="
                  bg-[#f7f8fc]
                "
              >
                <tr
                  className="
                    text-[11px]
                    font-bold
                    uppercase
                    tracking-[0.08em]
                    text-[#727784]
                  "
                >
                  <th className="px-6 py-4">
                    Recipient
                  </th>

                  <th className="px-4 py-4">
                    SMS
                  </th>

                  <th className="px-4 py-4">
                    WhatsApp
                  </th>

                  <th className="px-4 py-4">
                    AI Voice
                  </th>

                  <th className="px-4 py-4">
                    IVR
                  </th>

                  <th className="px-4 py-4">
                    Overall
                  </th>

                  <th className="px-6 py-4">
                    Last Activity
                  </th>
                </tr>
              </thead>

              <tbody>
                {recipients.map(
                  recipient => (
                    <tr
                      key={
                        recipient.id
                      }
                      className="
                        border-t
                        border-[#eceef4]
                        text-[13px]
                        text-[#414753]
                      "
                    >
                      <td className="px-6 py-5">
                        <p
                          className="
                            font-bold
                            text-[#191c22]
                          "
                        >
                          {recipient.fullName ??
                            "Customer"}
                        </p>

                        <p
                          className="
                            mt-1
                            text-[12px]
                            text-[#727784]
                          "
                        >
                          {recipient.phone}
                        </p>
                      </td>

                      <td className="px-4 py-5">
                        <ChannelStatusBadge
                          status={
                            recipient
                              .channels
                              .SMS
                              .status
                          }
                        />
                      </td>

                      <td className="px-4 py-5">
                        <ChannelStatusBadge
                          status={
                            recipient
                              .channels
                              .WHATSAPP
                              .status
                          }
                        />
                      </td>

                      <td className="px-4 py-5">
                        <ChannelStatusBadge
                          status={
                            recipient
                              .channels
                              .AI_VOICE
                              .status
                          }
                        />
                      </td>

                      <td className="px-4 py-5">
                        <ChannelStatusBadge
                          status={
                            recipient
                              .channels
                              .IVR
                              .status
                          }
                        />
                      </td>

                      <td className="px-4 py-5">
                        <OverallStatusBadge
                          status={
                            recipient.status
                          }
                        />
                      </td>

                      <td
                        className="
                          whitespace-nowrap
                          px-6
                          py-5
                          text-[12px]
                          text-[#727784]
                        "
                      >
                        {formatDateTime(
                          recipient
                            .lastActivityAt
                        )}
                      </td>
                    </tr>
                  )
                )}

                {recipients.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan={7}
                      className="
                        px-6
                        py-14
                        text-center
                        text-[13px]
                        text-[#727784]
                      "
                    >
                      No recipient execution data yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* =====================================
              PAGINATION
          ===================================== */}

          <div
            className="
              flex
              items-center
              justify-between
              border-t
              border-[#e6e8f1]
              px-7
              py-5
            "
          >
            <p
              className="
                text-[12px]
                text-[#727784]
              "
            >
              Page {pagination.page} of{" "}
              {pagination.totalPages}
            </p>

            <div
              className="
                flex
                gap-2
              "
            >
              <button
                type="button"
                disabled={
                  pagination.page <=
                  1
                }
                onClick={
                  () =>
                    setPage(
                      current =>
                        Math.max(
                          1,
                          current -
                            1
                        )
                    )
                }
                className="
                  rounded-full
                  border
                  border-[#c1c6d5]
                  px-4
                  py-2
                  text-[12px]
                  font-bold
                  text-[#414753]
                  disabled:cursor-not-allowed
                  disabled:opacity-40
                "
              >
                Previous
              </button>

              <button
                type="button"
                disabled={
                  pagination.page >=
                  pagination.totalPages
                }
                onClick={
                  () =>
                    setPage(
                      current =>
                        Math.min(
                          pagination
                            .totalPages,
                          current +
                            1
                        )
                    )
                }
                className="
                  rounded-full
                  bg-[#0056ad]
                  px-4
                  py-2
                  text-[12px]
                  font-bold
                  text-white
                  disabled:cursor-not-allowed
                  disabled:opacity-40
                "
              >
                Next
              </button>
            </div>
          </div>
        </section>

        <p
          className="
            mt-5
            text-[11px]
            leading-5
            text-[#8a8f98]
          "
        >
          “Sent” combines provider-accepted messages
          and dispatched call attempts. “Opened”
          represents WhatsApp read receipts. Opt-out
          count reflects current messaging consent for
          recipients in this campaign.
        </p>
      </main>
    </div>
  );
}

//--------------------------------------------------
// Main Metric
//--------------------------------------------------

function MetricCard({
  label,
  value,
  icon:
    Icon,
}: {
  label:
    string;

  value:
    string;

  icon:
    typeof Activity;
}) {
  return (
    <div
      className="
        rounded-[20px]
        border
        border-[#d9dce8]
        bg-white
        p-6
      "
    >
      <div
        className="
          flex
          h-10
          w-10
          items-center
          justify-center
          rounded-xl
          bg-[#eef4ff]
          text-[#005cba]
        "
      >
        <Icon
          size={20}
        />
      </div>

      <p
        className="
          mt-6
          text-[12px]
          font-semibold
          text-[#727784]
        "
      >
        {label}
      </p>

      <p
        className="
          mt-1
          text-[30px]
          font-semibold
          tracking-[-0.04em]
          text-[#191c22]
        "
      >
        {value}
      </p>
    </div>
  );
}

//--------------------------------------------------
// Small Metric
//--------------------------------------------------

function SmallMetric({
  label,
  value,
}: {
  label:
    string;

  value:
    string;
}) {
  return (
    <div
      className="
        rounded-2xl
        bg-[#f1f3f9]
        px-5
        py-4
      "
    >
      <p
        className="
          text-[11px]
          font-semibold
          text-[#727784]
        "
      >
        {label}
      </p>

      <p
        className="
          mt-1
          text-[20px]
          font-bold
          text-[#191c22]
        "
      >
        {value}
      </p>
    </div>
  );
}

//--------------------------------------------------
// Channel Card
//--------------------------------------------------

function ChannelCard({
  title,
  subtitle,
  metric,
  icon:
    Icon,
  enabled,
}: {
  title:
    string;

  subtitle:
    string;

  metric:
    string;

  icon:
    typeof Activity;

  enabled:
    boolean;
}) {
  return (
    <div
      className={[
        "rounded-2xl border p-5",
        enabled
          ? "border-[#d9dce8] bg-[#fbfcff]"
          : "border-[#eceef4] bg-[#f7f8fb] opacity-55",
      ].join(
        " "
      )}
    >
      <div
        className="
          flex
          items-center
          justify-between
          gap-4
        "
      >
        <div
          className="
            flex
            items-center
            gap-3
          "
        >
          <div
            className="
              flex
              h-10
              w-10
              items-center
              justify-center
              rounded-xl
              bg-white
              text-[#005cba]
            "
          >
            <Icon
              size={20}
            />
          </div>

          <div>
            <p
              className="
                text-[14px]
                font-bold
                text-[#191c22]
              "
            >
              {title}
            </p>

            <p
              className="
                mt-1
                text-[12px]
                text-[#727784]
              "
            >
              {enabled
                ? subtitle
                : "Not selected"}
            </p>
          </div>
        </div>

        {enabled && (
          <span
            className="
              rounded-full
              bg-[#e8f0fe]
              px-3
              py-1.5
              text-[11px]
              font-bold
              text-[#174ea6]
            "
          >
            {metric}
          </span>
        )}
      </div>
    </div>
  );
}

//--------------------------------------------------
// Channel Badge
//--------------------------------------------------

function ChannelStatusBadge({
  status,
}: {
  status:
    CommunicationChannelRuntimeStatus;
}) {
  const tone =
    statusTone(
      status
    );

  return (
    <span
      className={[
        "inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-[10px] font-bold",
        tone,
      ].join(
        " "
      )}
    >
      {prettyStatus(
        status
      )}
    </span>
  );
}

//--------------------------------------------------
// Overall Badge
//--------------------------------------------------

function OverallStatusBadge({
  status,
}: {
  status:
    CommunicationInsightStatus;
}) {
  const tone =
    status ===
      "COMPLETED" ||
    status ===
      "CONVERTED"
      ? "bg-green-50 text-green-700"
      : status ===
          "FAILED"
        ? "bg-red-50 text-red-700"
        : status ===
            "PARTIAL"
          ? "bg-amber-50 text-amber-800"
          : "bg-blue-50 text-blue-700";

  return (
    <span
      className={[
        "inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-[10px] font-bold",
        tone,
      ].join(
        " "
      )}
    >
      {prettyStatus(
        status
      )}
    </span>
  );
}

//--------------------------------------------------
// Campaign Badge
//--------------------------------------------------

function CampaignBadge({
  status,
}: {
  status:
    string;
}) {
  const terminalFailure =
    status ===
      "FAILED" ||
    status ===
      "CANCELLED";

  const complete =
    status ===
      "COMPLETED";

  return (
    <span
      className={[
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-bold",
        terminalFailure
          ? "bg-red-50 text-red-700"
          : complete
            ? "bg-green-50 text-green-700"
            : "bg-blue-50 text-blue-700",
      ].join(
        " "
      )}
    >
      {terminalFailure ? (
        <XCircle
          size={13}
        />
      ) : (
        <CheckCircle2
          size={13}
        />
      )}

      {prettyStatus(
        status
      )}
    </span>
  );
}

//--------------------------------------------------
// Formatting
//--------------------------------------------------

function statusTone(
  status:
    CommunicationChannelRuntimeStatus
): string {
  if (
    status ===
      "DELIVERED" ||
    status ===
      "READ" ||
    status ===
      "COMPLETED"
  ) {
    return "bg-green-50 text-green-700";
  }

  if (
    status ===
      "FAILED" ||
    status ===
      "UNDELIVERED" ||
    status ===
      "BUSY" ||
    status ===
      "NO_ANSWER" ||
    status ===
      "CANCELED"
  ) {
    return "bg-red-50 text-red-700";
  }

  if (
    status ===
    "NOT_SELECTED"
  ) {
    return "bg-[#f1f2f5] text-[#8a8f98]";
  }

  return "bg-blue-50 text-blue-700";
}

function prettyStatus(
  value:
    string
): string {
  return value
    .toLowerCase()
    .split(
      "_"
    )
    .map(
      part =>
        part
          .charAt(
            0
          )
          .toUpperCase() +
        part.slice(
          1
        )
    )
    .join(
      " "
    );
}

function formatDateTime(
  value:
    string
): string {
  const date =
    new Date(
      value
    );

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "—";
  }

  return new Intl.DateTimeFormat(
    "en-IN",
    {
      dateStyle:
        "medium",

      timeStyle:
        "short",
    }
  ).format(
    date
  );
}

function formatDuration(
  seconds:
    number |
    null
): string {
  if (
    seconds ===
      null ||
    !Number.isFinite(
      seconds
    )
  ) {
    return "—";
  }

  const rounded =
    Math.max(
      0,
      Math.round(
        seconds
      )
    );

  const minutes =
    Math.floor(
      rounded /
      60
    );

  const remaining =
    rounded %
    60;

  if (
    minutes ===
    0
  ) {
    return `${remaining}s`;
  }

  return `${minutes}:${String(
    remaining
  ).padStart(
    2,
    "0"
  )}`;
}