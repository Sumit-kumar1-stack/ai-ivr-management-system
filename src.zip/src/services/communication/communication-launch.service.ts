import {
  CommunicationCampaignStatus,
  CommunicationChannel,
} from "@prisma/client";

import {
  prisma,
} from "@/lib/prisma";

import {
  CommunicationCampaignQueueService,
} from "./communication-campaign-queue.service";

import {
  requirePublishedCommunicationIvrFlow,
} from "./communication-ivr-binding.service";

//--------------------------------------------------
// Launch
//--------------------------------------------------

export async function launchCommunicationCampaign(
  campaignId:
    string
) {
  const id =
    campaignId
      .trim();

  if (
    !id
  ) {
    throw new Error(
      "Communication campaign ID is required"
    );
  }

  //------------------------------------------------
  // Campaign
  //------------------------------------------------

  const campaign =
    await prisma
      .communicationCampaign
      .findUnique({
        where: {
          id,
        },

        select: {
          id:
            true,

          status:
            true,

          launchImmediately:
            true,

          scheduledAt:
            true,

          channels:
            true,

          ivrFlowId:
            true,

          _count: {
            select: {
              recipients:
                true,
            },
          },
        },
      });

  if (
    !campaign
  ) {
    throw new Error(
      "Communication campaign not found"
    );
  }

  //------------------------------------------------
  // Recipients
  //------------------------------------------------

  if (
    campaign
      ._count
      .recipients ===
    0
  ) {
    throw new Error(
      "Communication campaign has no recipient snapshots"
    );
  }

  //------------------------------------------------
  // Channels
  //------------------------------------------------

  if (
    campaign.channels
      .length ===
    0
  ) {
    throw new Error(
      "Communication campaign has no selected channels"
    );
  }

  //------------------------------------------------
  // IVR Must Be Configured Before Queueing
  //------------------------------------------------

  if (
    campaign.channels
      .includes(
        CommunicationChannel.IVR
      )
  ) {
    if (
      !campaign.ivrFlowId
    ) {
      throw new Error(
        "IVR_FLOW_CONFIGURATION_REQUIRED: Select a published IVR flow before launching this campaign."
      );
    }

    /*
     * Re-check at launch.
     *
     * The operator may have selected the flow earlier,
     * but it could have been changed/unpublished before
     * the campaign was launched.
     */
    await requirePublishedCommunicationIvrFlow(
      campaign.ivrFlowId
    );
  }

  //------------------------------------------------
  // Schedule
  //------------------------------------------------

  let delayMs =
    0;

  let scheduled =
    false;

  if (
    !campaign
      .launchImmediately
  ) {
    if (
      !campaign.scheduledAt
    ) {
      throw new Error(
        "Scheduled communication campaign has no scheduledAt value"
      );
    }

    delayMs =
      campaign
        .scheduledAt
        .getTime() -
      Date.now();

    if (
      delayMs >
      0
    ) {
      scheduled =
        true;
    } else {
      delayMs =
        0;
    }
  }

  const targetStatus =
    scheduled
      ? CommunicationCampaignStatus.SCHEDULED
      : CommunicationCampaignStatus.QUEUED;

  //------------------------------------------------
  // Atomic Claim
  //------------------------------------------------

  const claimed =
    await prisma
      .communicationCampaign
      .updateMany({
        where: {
          id:
            campaign.id,

          status: {
            in: [
              CommunicationCampaignStatus.DRAFT,
              CommunicationCampaignStatus.READY,
              CommunicationCampaignStatus.FAILED,
            ],
          },
        },

        data: {
          status:
            targetStatus,
        },
      });

  if (
    claimed.count ===
    0
  ) {
    throw new Error(
      `Communication campaign cannot be launched while status is ${campaign.status}`
    );
  }

  //------------------------------------------------
  // Queue
  //------------------------------------------------

  try {
    await CommunicationCampaignQueueService
      .enqueue(
        {
          communicationCampaignId:
            campaign.id,
        },
        delayMs
      );
  } catch (
    error
  ) {
    //------------------------------------------------
    // Compensation
    //------------------------------------------------

    await prisma
      .communicationCampaign
      .updateMany({
        where: {
          id:
            campaign.id,

          status:
            targetStatus,
        },

        data: {
          status:
            CommunicationCampaignStatus.FAILED,
        },
      });

    throw error;
  }

  return {
    communicationCampaignId:
      campaign.id,

    status:
      targetStatus,

    scheduled,

    scheduledAt:
      scheduled
        ? campaign
            .scheduledAt
            ?.toISOString() ??
          null
        : null,

    recipientCount:
      campaign
        ._count
        .recipients,
  };
}