import {
  CampaignRunStatus,
  CampaignStatus,
  CommunicationChannel,
} from "@prisma/client";

import {
  prisma,
} from "@/lib/prisma";

import {
  startCampaignExecution,
} from "@/services/campaigns/campaign-start.service";

import {
  ensureCommunicationContacts,
} from "./communication-contact-bridge.service";

import {
  resolveCommunicationVoiceRuntime,
} from "./communication-entitlement.service";

//--------------------------------------------------
// Result
//--------------------------------------------------

export interface CommunicationVoiceBridgeResult {
  queued:
    boolean;

  voiceCampaignId:
    string | null;

  campaignRunId:
    string | null;

  alreadyActive:
    boolean;
}

//--------------------------------------------------
// Bridge
//--------------------------------------------------

export async function startCommunicationVoiceCampaign(
  communicationCampaignId:
    string
): Promise<CommunicationVoiceBridgeResult> {
  const campaign =
    await prisma
      .communicationCampaign
      .findUnique({
        where: {
          id:
            communicationCampaignId,
        },

        include: {
          recipients:
            true,
        },
      });

  if (
    !campaign
  ) {
    throw new Error(
      "Communication campaign not found"
    );
  }

  //------------------------------------------------
  // AI Voice Not Selected
  //------------------------------------------------

if (
  !campaign.channels
    .includes(
      CommunicationChannel.AI_VOICE
    )
) {
  return {
    queued:
      false,

    voiceCampaignId:
      null,

    campaignRunId:
      null,

    alreadyActive:
      false,
  };
}

//------------------------------------------------
// M10 — Voice Runtime Guard
//------------------------------------------------

const voiceRuntime =
  resolveCommunicationVoiceRuntime(
    campaign.tier
  );

//------------------------------------------------
// This bridge is the existing cascaded runtime.
//
// PREMIUM must not silently fall through into the
// Standard Deepgram -> Gemini -> TTS pipeline.
// The next M10 window connects GEMINI_LIVE.
//------------------------------------------------

if (
  voiceRuntime !==
  "CASCADED"
) {
  throw new Error(
    "PREMIUM_GEMINI_LIVE_RUNTIME_REQUIRED"
  );
}

//------------------------------------------------
// Recipients
//------------------------------------------------

  if (
    campaign.recipients
      .length ===
    0
  ) {
    throw new Error(
      "Communication campaign has no recipients"
    );
  }

  //------------------------------------------------
  // Contacts
  //------------------------------------------------

  const contactIds =
    await ensureCommunicationContacts(
      campaign.recipients
    );

  //------------------------------------------------
  // Child AI Voice Campaign
  //------------------------------------------------

  const systemKey =
    `communication:${campaign.id}:voice`;

  const voiceCampaign =
    await prisma
      .campaign
      .upsert({
        where: {
          systemKey,
        },

        create: {
          name:
            `${campaign.name} - AI Voice`,

          description:
            `AI Voice child campaign for communication campaign ${campaign.id}`,

          systemKey,

          language:
            "English",

          voice:
            "Female",

          purpose:
            "GENERAL",

          scheduledAt:
            campaign
              .launchImmediately
              ? null
              : campaign
                  .scheduledAt,
        },

        update: {
          name:
            `${campaign.name} - AI Voice`,

          scheduledAt:
            campaign
              .launchImmediately
              ? null
              : campaign
                  .scheduledAt,
        },
      });

  //------------------------------------------------
  // Assign Contacts
  //------------------------------------------------

  await prisma
    .campaignContact
    .createMany({
      data:
        contactIds.map(
          contactId => ({
            campaignId:
              voiceCampaign.id,

            contactId,
          })
        ),

      skipDuplicates:
        true,
    });

  //------------------------------------------------
  // Parent Link
  //------------------------------------------------

  await prisma
    .communicationCampaign
    .update({
      where: {
        id:
          campaign.id,
      },

      data: {
        voiceCampaignId:
          voiceCampaign.id,
      },
    });

  //------------------------------------------------
  // Retry / Duplicate Worker Guard
  //------------------------------------------------

  if (
    isActiveCampaignStatus(
      voiceCampaign.status
    )
  ) {
    const activeRun =
      await prisma
        .campaignRun
        .findFirst({
          where: {
            campaignId:
              voiceCampaign.id,

            status: {
              in: [
                CampaignRunStatus.QUEUED,
                CampaignRunStatus.RUNNING,
              ],
            },
          },

          orderBy: {
            createdAt:
              "desc",
          },

          select: {
            id:
              true,
          },
        });

    return {
      queued:
        true,

      voiceCampaignId:
        voiceCampaign.id,

      campaignRunId:
        activeRun
          ?.id ??
        null,

      alreadyActive:
        true,
    };
  }

  //------------------------------------------------
  // Existing Production Voice Queue
  //------------------------------------------------

  const result =
    await startCampaignExecution(
      voiceCampaign.id
    );

  return {
    queued:
      true,

    voiceCampaignId:
      voiceCampaign.id,

    campaignRunId:
      result
        .campaignRunId,

    alreadyActive:
      false,
  };
}

//--------------------------------------------------
// Active
//--------------------------------------------------

function isActiveCampaignStatus(
  status:
    CampaignStatus
): boolean {
  return (
    status ===
      CampaignStatus.SCHEDULED ||
    status ===
      CampaignStatus.QUEUED ||
    status ===
      CampaignStatus.RUNNING
  );
}